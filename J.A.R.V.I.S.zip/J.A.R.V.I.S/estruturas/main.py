'''meu_chatbot

main.py #ponto de entrada do progrma (interface com o usuário)
core/   #Lógica central e configurações 
prompt_mestre.py #onde ficará a personalidade(P.T.R.F)
services/ #Integrações externas
ia_service.py #Onde faremos a chamada para a API da IA (futuramente)'''

import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

from core.prompt_mestre import PromptMestre
from services.ia_service import IAService

# -----------------------------------------------------------------------
# Inicialização do app e dos serviços
# -----------------------------------------------------------------------
app = Flask(
    __name__,
    static_folder="frontend",
    static_url_path=""
)

CORS(app)


# Inicializa o cérebro do J.A.R.V.I.S
prompt_mestre = PromptMestre()

# Inicializa o serviço de IA
ia_service = IAService()


# -----------------------------------------------------------------------
# Rota principal — Frontend do J.A.R.V.I.S
# -----------------------------------------------------------------------
@app.route("/")
def index():
    """
    Serve o frontend do J.A.R.V.I.S.
    """

    return send_from_directory(
        app.static_folder,
        "index.html"
    )


# -----------------------------------------------------------------------
# Rota principal do chat
# -----------------------------------------------------------------------
@app.route("/chat", methods=["POST"])
def chat():

    # Recebe os dados enviados pelo frontend
    dados = request.get_json()

    if not dados:

        return jsonify({
            "erro": "Nenhum dado recebido."
        }), 400

    # Mensagem enviada pelo usuário
    mensagem_usuario = dados.get(
        "mensagem",
        ""
    ).strip()

    # Histórico da conversa
    historico = dados.get(
        "historico",
        []
    )

    # Validação
    if not mensagem_usuario:

        return jsonify({
            "erro": "A mensagem não pode estar vazia."
        }), 400

    # Adiciona mensagem do usuário no histórico
    historico.append({
        "role": "user",
        "content": mensagem_usuario
    })

    try:

        # Gera o system prompt do J.A.R.V.I.S
        system_prompt = prompt_mestre.get_prompt()

        # Envia mensagem para a IA
        resposta_ia = ia_service.enviar_mensagem(
            mensagem_usuario,
            historico
        )

        # Retorna resposta
        return jsonify({
            "resposta": resposta_ia
        })

    except Exception as e:

        print(f"[ERRO J.A.R.V.I.S] {e}")

        return jsonify({
            "erro": str(e)
        }), 500


# -----------------------------------------------------------------------
# Status da API
# -----------------------------------------------------------------------
@app.route("/status")
def status():

    return jsonify({
        "status": "online",
        "bot": "J.A.R.V.I.S",
        "especialidade": "Marketing Digital e Redes Sociais"
    })


# -----------------------------------------------------------------------
# Inicialização do servidor
# -----------------------------------------------------------------------
if __name__ == "__main__":

    print("=" * 60)
    print("        J.A.R.V.I.S ONLINE")
    print("=" * 60)
    print("Frontend: http://localhost:5000")
    print("Chat API: http://localhost:5000/chat")
    print("Status:   http://localhost:5000/status")
    print("=" * 60)

    app.run(
        debug=True,
        port=5000
    )